#include "StdAfx.h"
#include "SegmentationForm.h"

