#pragma once

#include "../stdafx.h"

#include <Windows.h>
#include <gl/GL.h>
#include <gl/GLu.h>

int ClusterizationInitGL();