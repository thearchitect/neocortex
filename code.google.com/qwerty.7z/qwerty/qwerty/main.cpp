#include <iostream>
#include <fstream>
#include <conio.h>
#include <windows.h>
#include "glut.h"
#include <math.h>
#include <queue>
#include <vector>
#include <list>
#include <set>
//#include "my_lib.h"
#include "my_struct.h"
#include "c_point.h"
#include "c_edge.h"
#include "my_lib.h"

#define _USE_MATH_DEFINES

using namespace std;

const int VOXEL_SIZE=10;

GLfloat MIN_DENSITY = 1500;
GLfloat razm_x=1, razm_y=1, razm_z=1;
int COUNT_OF_POINTS_X=0, COUNT_OF_POINTS_Y=0, COUNT_OF_POINTS_Z=0;
int COUNT_OF_ALL_POINTS=0, COUNT_OF_ALL_SHOWED_POINTS=0;
int STEP=10;
int radius=0;
c_point camera_pos(0,0,-100000);
float angle=5.0f*M_PI/180;
short ***data3ar;

_data_size data_size;
_scale scale;
c_point *t_points;
//extern c_point *all_points;
list <c_edge> edges;
set <c_edge> all_edges;
set <c_point> s_points;
queue <t_triangle> triangles;
t_triangle *triangles_res;
int TRIANGLES_COUNT=0;
double qqq=0;
void DrawTriangle(c_point &p1, c_point &p2, c_point &p3)
{
	int HalfCountX=(all_points[COUNT_OF_ALL_SHOWED_POINTS-1].getX()-all_points[0].getX())/2;
	int HalfCountY=(all_points[COUNT_OF_ALL_SHOWED_POINTS-1].getY()-all_points[0].getY())/2;
	int HalfCountZ=(all_points[COUNT_OF_ALL_SHOWED_POINTS-1].getZ()-all_points[0].getZ())/2;

	double N=0.05;
	double RazmX_By_N=COUNT_OF_ALL_SHOWED_POINTS/3*N;
	double RazmY_By_N=COUNT_OF_ALL_SHOWED_POINTS/3*N;
	double RazmZ_By_N=COUNT_OF_ALL_SHOWED_POINTS/3*N;

	glBegin(GL_TRIANGLES);

	glVertex3f((p1.getX()-HalfCountX)*RazmX_By_N, (p1.getY()-HalfCountY)*RazmY_By_N, (p1.getZ()-HalfCountZ)*RazmZ_By_N);
	glVertex3f((p2.getX()-HalfCountX)*RazmX_By_N, (p2.getY()-HalfCountY)*RazmY_By_N, (p2.getZ()-HalfCountZ)*RazmZ_By_N);
	glVertex3f((p3.getX()-HalfCountX)*RazmX_By_N, (p3.getY()-HalfCountY)*RazmY_By_N, (p3.getZ()-HalfCountZ)*RazmZ_By_N);
	
	glEnd();
}

void DrawCube(GLfloat x1, GLfloat y1, GLfloat z1, GLfloat x2, GLfloat y2, GLfloat z2)
{
    glBegin(GL_QUADS);

    // ����� 
    glVertex3f(x1, y1, z1);                        //1
    glVertex3f(x1, y2, z1);                        //2
    glVertex3f(x1, y2, z2);			               //3
    glVertex3f(x1, y1, z2);                        //4

    // ������ 
    glVertex3f(x2, y1, z1);                        //5
    glVertex3f(x2, y2, z1);                        //6
    glVertex3f(x2, y2, z2);			               //7
    glVertex3f(x2, y1, z2);                        //8

    // ������ 
    glVertex3f(x1, y1, z1);                        //1
    glVertex3f(x1, y1, z2);                        //4
    glVertex3f(x2, y1, z2);                        //8
    glVertex3f(x2, y1, z1);                        //5
    

    // ������� 
    glVertex3f(x1, y2, z1);                        //2
    glVertex3f(x1, y2, z2);			               //3
    glVertex3f(x2, y2, z2);			               //7
    glVertex3f(x2, y2, z1);                        //6

    // ������ 
    glVertex3f(x1, y1, z2);                        //4
    glVertex3f(x1, y2, z2);			               //3
    glVertex3f(x2, y2, z2);			               //7
    glVertex3f(x2, y1, z2);                        //8

    // ��������
    glVertex3f(x1, y1, z1);                        //1
    glVertex3f(x1, y2, z1);                        //2
    glVertex3f(x2, y2, z1);                        //6
    glVertex3f(x2, y1, z1);                        //5

    glEnd();
}

void drawAxises()
{
	glColor4f(1,0,0,0.1f);
	glBegin(GL_LINES);
	glVertex3f(0,0,0);
	glVertex3f(10000000,0,0);
	glEnd();

	glColor4f(0,1,0,0.1f);
	glBegin(GL_LINES);
	glVertex3f(0,0,0);
	glVertex3f(0,10000000,0);
	glEnd();

	glColor4f(0,0,1,0.1f);
	glBegin(GL_LINES);
	glVertex3f(0,0,0);
	glVertex3f(0,0,10000000);
	glEnd();

}
int neighbor_point_to_i(c_point &point, unsigned char var, int act)
{
	int x=point.getX();
	int y=point.getY();
	int z=point.getZ();

	switch (var)
	{
	case 'x':
			return (x+act)*COUNT_OF_POINTS_Y*COUNT_OF_POINTS_Z + y*COUNT_OF_POINTS_Z + z;
	case 'y':
			return x*COUNT_OF_POINTS_Y*COUNT_OF_POINTS_Z + (y+act)*COUNT_OF_POINTS_Z + z;
	case 'z':
			return x*COUNT_OF_POINTS_Y*COUNT_OF_POINTS_Z + y*COUNT_OF_POINTS_Z + z+act;
	default :
			throw "ERROR: main.cpp: neighbor_point_to_i(): incorrect coordinate";
	}
}

int diag_point_to_i(c_point &point, int actX, int actY, int actZ)
{
	int x=point.getX();
	int y=point.getY();
	int z=point.getZ();

	return (x+actX)*COUNT_OF_POINTS_Y*COUNT_OF_POINTS_Z + (y+actY)*COUNT_OF_POINTS_Z + z+actZ;
}



bool IsBorder(int i, c_point *t_points, float MIN_DENSITY)
{
	if(t_points[i].getVal()<MIN_DENSITY) return false;
	else return true;
    //if(t_points[neighbor_point_to_i(t_points[i], 'z',  1)].getVal()<MIN_DENSITY) return true;
    //if(t_points[neighbor_point_to_i(t_points[i], 'z', -1)].getVal()<MIN_DENSITY) return true;
    //if(t_points[neighbor_point_to_i(t_points[i], 'y',  1)].getVal()<MIN_DENSITY) return true;
    //if(t_points[neighbor_point_to_i(t_points[i], 'y', -1)].getVal()<MIN_DENSITY) return true;
    //if(t_points[neighbor_point_to_i(t_points[i], 'x',  1)].getVal()<MIN_DENSITY) return true;
    //if(t_points[neighbor_point_to_i(t_points[i], 'x', -1)].getVal()<MIN_DENSITY) return true;  

    //if(t_points[diag_point_to_i(t_points[i], -1,  1, -1)].getVal()<MIN_DENSITY) return true;
    //if(t_points[diag_point_to_i(t_points[i], -1,  1,  1)].getVal()<MIN_DENSITY) return true;
    //if(t_points[diag_point_to_i(t_points[i], -1, -1, -1)].getVal()<MIN_DENSITY) return true;
    //if(t_points[diag_point_to_i(t_points[i], -1, -1,  1)].getVal()<MIN_DENSITY) return true;
    //if(t_points[diag_point_to_i(t_points[i],  1,  1, -1)].getVal()<MIN_DENSITY) return true;
    //if(t_points[diag_point_to_i(t_points[i],  1,  1,  1)].getVal()<MIN_DENSITY) return true;
    //if(t_points[diag_point_to_i(t_points[i],  1, -1, -1)].getVal()<MIN_DENSITY) return true;
    //if(t_points[diag_point_to_i(t_points[i],  1, -1,  1)].getVal()<MIN_DENSITY) return true;
    //return false;
}

bool SelectPoints(int x, int y, int z, int min_dens, int max_dens)
{
	if(data3ar[x][y][z]<=max_dens && data3ar[x][y][z]>=min_dens)
		return true;
	return false;
}

void RenderScene(void)
{
	int HalfCountX=COUNT_OF_POINTS_X/2;
	int HalfCountY=COUNT_OF_POINTS_Y/2;
	int HalfCountZ=COUNT_OF_POINTS_Z/2;

	int N=10;
	int RazmX_By_N=razm_x*N;
	int RazmY_By_N=razm_y*N;
	int RazmZ_By_N=razm_z*N;

	glMatrixMode(GL_MODELVIEW);
    glClear(GL_COLOR_BUFFER_BIT);

    glPolygonMode(GL_FRONT_AND_BACK, GL_LINE);
	glPushMatrix();

	glColor4f(1,1,1,0.1f);
//glBegin(GL_POINTS);
//	for(int i=0; i<COUNT_OF_ALL_SHOWED_POINTS; i++)
//			glVertex3f((all_points[i].getX()-HalfCountX)*RazmX_By_N,(all_points[i].getY()-HalfCountY)*RazmY_By_N,(all_points[i].getZ()-HalfCountZ)*RazmZ_By_N);
//glEnd();

	for(int i=0; i<TRIANGLES_COUNT; i++)
		DrawTriangle(triangles_res[i].point1, triangles_res[i].point2, triangles_res[i].point3);

	drawAxises();
    glPopMatrix();
    glutSwapBuffers();
}

void calc_showed_points(c_point *t_points, int count, float min_dens)
{
	COUNT_OF_ALL_SHOWED_POINTS=0;
	for(int i=0; i<count; i++)
		if(IsBorder(i, t_points, min_dens))
			COUNT_OF_ALL_SHOWED_POINTS++;

	all_points = new c_point[COUNT_OF_ALL_SHOWED_POINTS];
	int count_of_showed_tmp=0;
	for(int i=0; i<count; i++)
		if(IsBorder(i, t_points, min_dens))
		{
			all_points[count_of_showed_tmp]=t_points[i];
			count_of_showed_tmp++;
		}
}

void ManageKeys(unsigned char key, int x, int y)
{
	switch ( key )
	{
		case (unsigned char)233:	//�
		case 'q':
		{
		   // ������� ��������
		   camera_pos=c_point(camera_pos.getX(), camera_pos.getY()*cos(angle)+camera_pos.getZ()*sin(angle), -camera_pos.getY()*sin(angle)+camera_pos.getZ()*cos(angle));
		   glRotatef(5.0f,1.0,0.0,0.0);
		   glutPostRedisplay();
		   break;
		}

		case (unsigned char)244:	//�
		case 'a':
		{
		   // ������� ��������
		   camera_pos=c_point(camera_pos.getX(), camera_pos.getY()*cos(-angle)+camera_pos.getZ()*sin(-angle), -camera_pos.getY()*sin(-angle)+camera_pos.getZ()*cos(-angle));
		   glRotatef(-5.0f,1.0,0.0,0.0);
		   glutPostRedisplay();
		   break;
		}

		case (unsigned char)246:	//�
		case 'w':
		{
		   // ������� ��������
		   camera_pos=c_point(camera_pos.getX()*cos(angle)-camera_pos.getZ()*sin(angle), camera_pos.getY(), camera_pos.getX()*sin(angle)+camera_pos.getZ()*cos(angle));
		   glRotatef(5.0f,0.0,1.0,0.0);
		   glutPostRedisplay();
		   break;
		}

		case (unsigned char)251:	//�
		case 's':
		{
		   // ������� ��������
		   camera_pos=c_point(camera_pos.getX()*cos(-angle)-camera_pos.getZ()*sin(-angle), camera_pos.getY(), camera_pos.getX()*sin(-angle)+camera_pos.getZ()*cos(-angle));
		   glRotatef(-5.0f,0.0,1.0,0.0);
		   glutPostRedisplay();
		   break;
		}

		case (unsigned char)243:	//�
		case 'e':
		{
		   // ������� ��������
		   camera_pos=c_point(camera_pos.getX()*cos(angle)+camera_pos.getY()*sin(angle), -camera_pos.getX()*sin(angle)+camera_pos.getY()*cos(angle), camera_pos.getZ());
		   glRotatef(5.0f,0.0,0.0,1.0);
		   glutPostRedisplay();
		   break;
		}

		case (unsigned char)226:	//�
		case 'd':
		{
		   // ������� ��������
		   camera_pos=c_point(camera_pos.getX()*cos(-angle)+camera_pos.getY()*sin(-angle), -camera_pos.getX()*sin(-angle)+camera_pos.getY()*cos(-angle), camera_pos.getZ());
		   glRotatef(-5.0f,0.0,0.0,1.0);
		   glutPostRedisplay();
		   break;
		}

		case (unsigned char)234:	//�
		case 'r':
		{
		   glTranslatef(camera_pos.getX(), camera_pos.getY(), camera_pos.getZ());
		   glutPostRedisplay();
		   break;
		}

		case (unsigned char)224:	//�
		case 'f':
		{
		   glTranslatef(-camera_pos.getX(), -camera_pos.getY(), -camera_pos.getZ());
		   glutPostRedisplay();
		   break;
		}

	}
}

void SetupRC(void)
{
     glClearColor(0.0f,0.0f,0.0f,1.0f);
     glColor3f(0.0f, 1.0f, 0.0f); 
}

void ChangeSize(GLsizei w, GLsizei h)
{
     GLfloat aspectRatio;
     if(h==0) h=1;
     glViewport(0,0,w,h);
     glMatrixMode(GL_PROJECTION);
     glLoadIdentity();
     aspectRatio=(GLfloat)w/(GLfloat)h;
     gluPerspective(40.0, (GLfloat) w/(GLfloat) h, .0, 20.0);
     glMatrixMode(GL_MODELVIEW);
     glLoadIdentity();
	 gluLookAt(0,0,35*COUNT_OF_ALL_SHOWED_POINTS,0,0,0,0,1,0);

	 camera_pos.setX(0);
	 camera_pos.setY(0);
	 camera_pos.setZ(-100000);
}

bool if_edge_is_full(c_edge &edge, bool update=false)
{
	bool edge_is_full=false;
	bool edge_already_exist=false;

	set <c_edge>::iterator iter=all_edges.find(edge);
	if(iter!=all_edges.end())
	{
		edge_already_exist=true;
		if(update) iter->update(edge);
		if(iter->is_lp_exists && iter->is_rp_exists)
			edge_is_full=true;
	}
	else
	{
		if(update) all_edges.insert(edge);
	}
	
	return edge_is_full;
}

int if_point_on_ball(c_edge &edge, c_point &center, list <c_point> &points)
{
	int point_num=-1, point_num_res=-1;
	double x=0, y=0, z=0;
	double dist=99999999, dist_tmp=99999999;
	
	c_point &point1=all_points[edge.getFP()];
	c_point &point2=all_points[edge.getSP()];

	for(list <c_point>::iterator point_iter=points.begin(); point_iter!=points.end(); point_iter++)
	{
		if ((*point_iter==point1) || (*point_iter==point2)) continue;
		
		// ���� ���������� ����� ������ � ������� ����� ����� ������� �� ����� ����� �� ����������� �����
		// ���� ��� ������ ��� ������ �� ����� ������
		float cur_dist=point_iter->get_dist_points(center).getVal();
		
		float flt=0.01;
		if (cur_dist<radius-flt) return -2;
		if ((cur_dist<radius+flt)&&(cur_dist>radius-flt))
		{
			point_num=point_iter->getNum();

			float scalar=scalarMultiply(calc_normal(all_points[edge.getFP()], all_points[edge.getSP()], all_points[point_num], center),
										vectorsMultiply(all_points[edge.getFP()], all_points[edge.getSP()], all_points[point_num]));
			if(scalar>0)		//����� �����
			{
				if(edge.is_lp_exists) continue;
			}
			else if(scalar<0)	//������ �����
			{
				if(edge.is_rp_exists) continue;
			}

			c_edge e1(edge.getFP(), point_num);
			c_edge e2(edge.getSP(), point_num);
			if(if_edge_is_full(e1) || if_edge_is_full(e2)) continue;

			dist_tmp=all_points[edge.getFP()].get_dist_points(*point_iter).getVal();
			if(dist_tmp<dist)
			{
				dist=dist_tmp;
				point_num_res=point_num;
			}
		}
	}

	return point_num_res;
}

int find_point(c_edge &edge, c_point *points, c_point &endCenterPos)
{
	float a=0;			//���� ��������
	int point_num=-1;
	int direct=1;		//����������� �������� ����. 1-�� �������
	c_point center, null_center;

	if(edge.is_lp_exists && edge.is_rp_exists) return -1;
	if(edge.is_rp_exists) direct=-1; 
	
	list <c_point> my_points;

	getPointsSection(points, 0, COUNT_OF_ALL_SHOWED_POINTS-1, all_points[edge.getFP()], 2*radius, my_points);	//������� ����� � �������� 2*������ �� �������� �����

	int multiplier=1000000;							// for more correct result
	int grad=180, step=45*multiplier; 
	int first=0, last=0, mid=0;
	bool point_inside=false;

	if(edge.is_lp_exists || edge.is_rp_exists) center=edge.center;
	else center=edge.calc_center_ball(radius, c_point(-1, 0, 0));

	//��������� ��������� ��������� ������
	null_center=center;

	for(int i=0; i<grad*multiplier; i+=step)		//������� �� grad ��������
	{						
		center=null_center;
		//������� ������ edge
		center.rotatePoint(points[edge.getFP()], points[edge.getSP()], ((float)(direct*i))/multiplier);

		point_num=if_point_on_ball(edge, center, my_points);
		if (point_num>=0) break;					// ����� �� �����
		if (point_num!=-2) continue;				// ����� �����
		else point_inside=true;						// ����� ������

		first=i-step; last=i; mid=(first+last)/2;
		while(first<last)
		{
			center=null_center;
			//������� ������ edge
			center.rotatePoint(points[edge.getFP()], points[edge.getSP()], ((float)(direct*mid))/multiplier);

			point_num=if_point_on_ball(edge, center, my_points);
			if (point_num>=0) break;				// ����� �� �����
			if (point_num==-2) last=mid;			// ����� ������
			else first=mid+1;
			mid=(first+last)/2;
			if(first==-45000000 && last==-44999999)
				last=first;
		}

		if (point_inside) break;
	}

	//��������� ������� ��������� ������
	if (point_num>=0) endCenterPos=center;

	return point_num;
}

void ball_pivot(c_point *points)
{
	c_edge seed_edge;
	c_edge cur_edge;
	c_edge new_edge;

	c_point center;
	int point_num=-1;

	seed_edge=c_edge(0, 1);
	edges.push_back(seed_edge);
	all_edges.insert(seed_edge);

	t_triangle triangle;
	bool edge_already_exists=false;
	bool edge_is_full=false;

	while(edges.size())
	{
		cur_edge=edges.front();
		point_num=find_point(cur_edge, points, center);
		
		//if(point_num==-2) 
		//{
		//	//cout<<"ERROR: main.cpp: ball_pivot(): point_num==-2"<<endl<<
		//	//	"edge:"<<cur_edge.getFP()<<","<<cur_edge.getSP()<<"  Left:"<<cur_edge.getLP()<<"  Right:"<<cur_edge.getRP()<<endl;

		//	//throw "ERROR: main.cpp: ball_pivot(): point_num==-2";
		//}

		if(point_num>=0)
		{
			//edge 1
			new_edge=c_edge(cur_edge.getFP(), point_num, cur_edge.getSP(), center);

			edge_is_full=if_edge_is_full(new_edge, true);

			for(list <c_edge>::iterator iter=edges.begin(); iter!=edges.end(); iter++)
				if(*iter==new_edge)
				{
					iter->update(new_edge);
					edge_already_exists=true;
					if(edge_is_full) edges.erase(iter);
					break;
				}
			if(!edge_already_exists && !edge_is_full) edges.push_back(new_edge);
			edge_already_exists=false;
			edge_is_full=false;

			//edge 2
			new_edge=c_edge(cur_edge.getSP(), point_num, cur_edge.getFP(), center);

			edge_is_full=if_edge_is_full(new_edge, true);

			for(list <c_edge>::iterator iter=edges.begin(); iter!=edges.end(); iter++)
				if(*iter==new_edge)
				{
					iter->update(new_edge);
					edge_already_exists=true;
					if(edge_is_full) edges.erase(iter);
					break;
				}
			if(!edge_already_exists && !edge_is_full) edges.push_back(new_edge);
			edge_already_exists=false;
			edge_is_full=false;

			// save cur_edge
			cur_edge.add_point(point_num);
			if_edge_is_full(cur_edge, true);

			//save triangle
			triangle.point1=all_points[cur_edge.getFP()];
			triangle.point2=all_points[cur_edge.getSP()];
			triangle.point3=points[point_num];
			triangles.push(triangle);
		}

		edges.pop_front();
	}
}

void get_triangles()
{
	TRIANGLES_COUNT=triangles.size();
	cout<<TRIANGLES_COUNT<<endl;
	triangles_res=new t_triangle[triangles.size()];
	int i=0;
	
	while (triangles.size())
	{
		triangles_res[i]=triangles.front();
		triangles.pop();
		i++;
	}
}

void init_data(char * file)
{
	radius=60;
	std::ifstream fs(file,std::ios::in | std::ios::binary);
	short *data1ar;
	fs.read((char*)&data_size.x,sizeof(int));
	fs.read((char*)&data_size.y,sizeof(int));
	fs.read((char*)&data_size.z,sizeof(int));

	fs.read((char*)&scale.x,sizeof(float));
	fs.read((char*)&scale.y,sizeof(float));
	fs.read((char*)&scale.z,sizeof(float));
	data1ar = new short [data_size.x*data_size.y*data_size.z];
	data3ar = new short **[data_size.x];
	for( int i = 0; i < data_size.x; i++ )
	{
		data3ar[i] = new short *[data_size.y];
		for( int j = 0; j < data_size.y; j++)
		{
			data3ar[i][j] = new short[data_size.z];
		}
	}

	fs.read((char*)data1ar,sizeof( short ) * data_size.x * data_size.y * data_size.z);
	for(int x=0; x<data_size.x; x++)
		for(int y=0; y<data_size.y; y++)
			for(int z=0; z<data_size.z; z++)
				data3ar[x][y][z] = data1ar[z*data_size.y*data_size.x+y*data_size.x+x];

	COUNT_OF_POINTS_X=data_size.x/STEP;
	COUNT_OF_POINTS_Y=data_size.y/STEP;
	COUNT_OF_POINTS_Z=data_size.z/STEP;
	
	razm_x=scale.x;
	razm_y=scale.y;
	razm_z=scale.z;

	COUNT_OF_ALL_POINTS=COUNT_OF_POINTS_X*COUNT_OF_POINTS_Y*COUNT_OF_POINTS_Z;
	t_points=new c_point[COUNT_OF_ALL_POINTS];

	for(int i=0; i<COUNT_OF_POINTS_X; i++)
	{
		for(int j=0; j<COUNT_OF_POINTS_Y; j++)
		{
			for(int k=0; k<COUNT_OF_POINTS_Z; k++)
			{
				
				t_points[i*COUNT_OF_POINTS_Y*COUNT_OF_POINTS_Z + j*COUNT_OF_POINTS_Z + k].setX(i);
				t_points[i*COUNT_OF_POINTS_Y*COUNT_OF_POINTS_Z + j*COUNT_OF_POINTS_Z + k].setY(j);
				t_points[i*COUNT_OF_POINTS_Y*COUNT_OF_POINTS_Z + j*COUNT_OF_POINTS_Z + k].setZ(k);
				t_points[i*COUNT_OF_POINTS_Y*COUNT_OF_POINTS_Z + j*COUNT_OF_POINTS_Z + k].setVal(data3ar[i*STEP][j*STEP][k*STEP]);
			}
		}
	}

	fs.close();
	delete []data1ar;
	for( int i = 0; i < data_size.x; i++ )
	{
		for( int j = 0; j < data_size.y; j++)
			delete []data3ar[i][j];
		delete []data3ar[i];
	}
	delete []data3ar;
}

void main(void)
{
	init_data("head.bin");
	
	std::cout<<"Count of all points:"<<std::endl;
	std::cout<<data_size.x * data_size.y * data_size.z<<std::endl;
	std::cout<<"Sizes:"<<std::endl;
	std::cout<<"x:"<<data_size.x<<std::endl;
	std::cout<<"y:"<<data_size.y<<std::endl;
	std::cout<<"z:"<<data_size.z<<std::endl;
	std::cout<<"Sizes of voxel"<<std::endl;
	std::cout<<"x:"<<scale.x<<std::endl;
	std::cout<<"y:"<<scale.y<<std::endl;
	std::cout<<"z:"<<scale.z<<std::endl;

	calc_showed_points(t_points, COUNT_OF_ALL_POINTS, MIN_DENSITY);
	cout<<endl<<COUNT_OF_ALL_SHOWED_POINTS<<endl;
	//COUNT_OF_ALL_SHOWED_POINTS=1500;
	//radius=80;
	//all_points = new c_point[COUNT_OF_ALL_SHOWED_POINTS];

	//for (int i=0; i<COUNT_OF_ALL_SHOWED_POINTS; i++)
	//{
	//		all_points[i].setX(i/(int)sqrt((double)COUNT_OF_ALL_SHOWED_POINTS)*50);
	//		all_points[i].setY(i%(int)sqrt((double)COUNT_OF_ALL_SHOWED_POINTS)*50);
	//		all_points[i].setZ(0);
	//		all_points[i].setVal(0);
	//		all_points[i].setNum(i);
	//}
	//for (int i=0; i<COUNT_OF_ALL_SHOWED_POINTS; i++)
	//{
	//	all_points[i].setX(rand()%500);
	//	all_points[i].setY(rand()%500);
	//	all_points[i].setZ(-1*(rand()%500));
	//}

	//		all_points[0].setX(0);
	//		all_points[0].setY(0);
	//		all_points[0].setZ(0);

	//		all_points[1].setX(0);
	//		all_points[1].setY(20);
	//		all_points[1].setZ(0);


	LARGE_INTEGER before, after, freq;
    QueryPerformanceFrequency(&freq);
	QueryPerformanceCounter(&before);
	sortArrOfPoints(all_points, COUNT_OF_ALL_SHOWED_POINTS);
	QueryPerformanceCounter(&after);
	double cpu_time = (after.QuadPart - before.QuadPart) / double(freq.QuadPart);
	cout<<cpu_time;

cout<<" sorted"<<endl;

//---------

    QueryPerformanceFrequency(&freq);
	QueryPerformanceCounter(&before);

	ball_pivot(all_points);
	get_triangles();
	
	QueryPerformanceCounter(&after);
    cpu_time = (after.QuadPart - before.QuadPart) / double(freq.QuadPart);
	cout<<cpu_time;

	glutInitDisplayMode(GLUT_DOUBLE | GLUT_RGB);
	glutInitWindowSize(500,500);
	glutCreateWindow("Simple");
	   
	SetupRC();
	glutDisplayFunc(RenderScene);
	glutReshapeFunc(ChangeSize);
	glutKeyboardFunc(ManageKeys);
	   
	glutMainLoop();

	delete []t_points;
	delete []all_points;
	delete []triangles_res;
}
