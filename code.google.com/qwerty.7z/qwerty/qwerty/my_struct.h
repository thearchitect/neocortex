#ifndef MY_STRUCT_H
#define MY_STRUCT_H

#include "c_point.h"

extern const float PI;
extern double fault=0.00001;

struct _data_size
{
    int x;
    int y;
    int z;
};

struct _scale
{
    float x;
    float y;
    float z;
};

struct t_triangle
{
	c_point point1;
	c_point point2;
	c_point point3;
};

#endif MY_STRUCT_H