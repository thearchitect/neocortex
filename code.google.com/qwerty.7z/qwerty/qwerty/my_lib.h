#ifndef MY_LIB_H
#define MY_LIB_H

#include <math.h>
#include <iostream>
#include <set>
#include "c_point.h"

/*
	Sort array of points to the following format:
	N X Y Z
	0 0 0 0
	1 0 0 1
	2 0 1 0
	3 0 1 1
	4 1 0 0
*/
void sortArrOfPoints(c_point* points, int &len)	
{
	std::set<c_point> pnts;
	for(int j=0; j<len; j++)
		pnts.insert(points[j]);

	int i=0;
	c_point nullPoint;
	for (set<c_point>::iterator iter=pnts.begin(); iter!=pnts.end(); iter++)
	{
		if(iter->getX()==0) continue;
		iter->setNum(i); 
		points[i]=*iter;
		if(i==0) nullPoint=points[0];
		points[i]=points[i]-nullPoint;
		points[i]=points[i]*30;
//		cout<<i<<"   "<<"("<<points[i].getX()<<","<<points[i].getY()<<","<<points[i].getZ()<<")"<<endl;
		i++;
	}
	len=i;
}

int getLeftPos(c_point *points, int first, int last, float val, char coord)
{
	if(val <= points[first].getCoord(coord)) return first;
	if(val > points[last].getCoord(coord)) return -1;

	while(first<last)
	{
		int mid=(first+last)/2;
		if(val<=points[mid].getCoord(coord)) last=mid;
		else first=mid+1;
	}
	
	return first;
}

int getRightPos(c_point *points, int first, int last, float val, char coord)
{
	if(val >= points[last].getCoord(coord)) return last;
	if(val < points[first].getCoord(coord)) return -1;

	while(first<last)
	{
		int mid=(first+last)/2;
		if(val<points[mid].getCoord(coord)) last=mid;
		else first=mid+1;
	}
	
	if (val<points[first].getCoord(coord)) return first-1;
	return first;
}

void getPointsSection(c_point *points, int first, int last, c_point coords, int dist, list<c_point> &result, char coord='x')
{
	int f=getLeftPos(points, first, last, coords.getCoord(coord)-dist, coord);
	int l=getRightPos(points, first, last, coords.getCoord(coord)+dist, coord);

	if(f!=-1 && l!=-1)
	{
		if(coord!='z')
			while(f<=l)
			{
				int sub_l=getRightPos(points, f, l, points[f].getCoord(coord), coord);
				getPointsSection(points, f, sub_l, coords, dist, result, (char)(coord+1));
				f=sub_l+1;
			}
		else
			for(int i=f; i<=l; i++)
				result.push_back(points[i]);
	}
}

c_point vectorsMultiply(const c_point& p1, const c_point& p2, const c_point& p3)
{
	c_point res;
	c_point vec1=p2-p1;
	c_point vec2=p3-p1;

	res.setX(vec1.getY()*vec2.getZ()-vec1.getZ()*vec2.getY());
	res.setY(vec1.getZ()*vec2.getX()-vec1.getX()*vec2.getZ());
	res.setZ(vec1.getX()*vec2.getY()-vec1.getY()*vec2.getX());

	float dist=sqrt(res.getX()*res.getX()+res.getY()*res.getY()+res.getZ()*res.getZ());

	res.setX(res.getX()/dist);
	res.setY(res.getY()/dist);
	res.setZ(res.getZ()/dist);

	return res;
}

float scalarMultiply(const c_point& vec1, const c_point& vec2)
{
	return (vec1.getX()*vec2.getX()+vec1.getY()*vec2.getY()+vec1.getZ()*vec2.getZ());
}

c_point calc_normal(const c_point& p1, const c_point& p2, const c_point& p3, const c_point& centerBall)
{
	// �������� ��������� ���������
	float A=p1.getY() * (p2.getZ() - p3.getZ()) + p2.getY() * (p3.getZ() - p1.getZ()) + p3.getY() * (p1.getZ() - p2.getZ());
	float B=p1.getZ() * (p2.getX() - p3.getX()) + p2.getZ() * (p3.getX() - p1.getX()) + p3.getZ() * (p1.getX() - p2.getX());
	float C=p1.getX() * (p2.getY() - p3.getY()) + p2.getX() * (p3.getY() - p1.getY()) + p3.getX() * (p1.getY() - p2.getY());
	float D=-p1.getX() * (p2.getY() * p3.getZ() - p3.getY() * p2.getZ()) - p2.getX() * (p3.getY() * p1.getZ() - p1.getY() * p3.getZ()) - p3.getX() * (p1.getY() * p2.getZ() - p2.getY() * p1.getZ());

	//������ �������
	float x=A*(A*centerBall.getX()+B*centerBall.getY()+C*centerBall.getZ()+D)/(A*A+B*B+C*C);
	float y=B*(A*centerBall.getX()+B*centerBall.getY()+C*centerBall.getZ()+D)/(A*A+B*B+C*C);
	float z=C*(A*centerBall.getX()+B*centerBall.getY()+C*centerBall.getZ()+D)/(A*A+B*B+C*C);

	//���������
	float dist=sqrt(x*x+y*y+z*z);
	x/=dist;
	y/=dist;
	z/=dist;

	return c_point(x,y,z);
}

float round(float chislo, int n)
/************************************************/
/* ���������� �����. */
/* ����: chislo - ����� ������� �����������. */
/* n - ����� ������ ����� ������� */
/* (�� �������� ���������� ����������). */
/* �����: ������� ���������� ����������� �����. */
/************************************************/
{
	float result;
	__int64 iChislo;
	float drob;
	int k=0;
	
	if (chislo<0) k=-1;
	else k=1;
	
	iChislo = (__int64) chislo;
	drob = chislo - iChislo;
	result=((__int64) (drob*pow(10.0,n)))/pow(10.0,n);
	result = iChislo + result;
	return result;
}

#endif MY_LIB_H